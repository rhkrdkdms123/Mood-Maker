package com.example.iothome;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ogaclejapan.smarttablayout.SmartTabLayout;

import java.util.ArrayList;

public class WindowFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.fragment_window, container, false);

        final List<_Fragment> fragments = new ArrayList<>();
        fragments.add(WindowRoomFragment.newInstance(null, null));
        fragments.add(InterestFragment.newInstance());
        fragments.add(PopularFragment.newInstance());
        fragments.add(MyProfileFragment.newInstance());

        FragmentPagerAdapter adapter = new FragmentPagerAdapter(getActivity().getSupportFragmentManager()) {
            @Override
            public CharSequence getPageTitle(int position) {
                return fragments.get(position).getTitle(getActivity());
            }

            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }

            @Override
            public int getCount() {
                return fragments.size();
            }
        };

        getActivity().setTitle(fragments.get(0).getTitle(getActivity()));
        ViewPager pager = (ViewPager) layout.findViewById(R.id.window_viewpager);
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                getActivity().setTitle(fragments.get(position).getTitle(getActivity()));
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        pager.setAdapter(adapter);
        ((SmartTabLayout) layout.findViewById(R.id.main_viewpagertab)).setViewPager(pager);

        return layout;
    }
}